package com.notifplatform.notificationservice.dto;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

// this is the contract published to kafka — workers deserialize this exact shape
@Data
@Builder
public class NotificationEvent {

    private UUID notificationId;    // unique id for idempotency and audit tracking
    private String userId;          // externalId from user-service
    private String type;            // e.g. ORDER_SHIPPED, PASSWORD_RESET
    private Map<String, Object> data; // flexible payload: trackingCode, amount, etc.
    private Instant createdAt;
}
